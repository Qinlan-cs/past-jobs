//#ifndef PATHNAME_H
//#define PATHNAME_H

//#include <string>
//const std::string PATH = "/Users/ty/Documents/Project/Files/";
//const std::string NAME = "arithemetic";      // 无后缀

//#endif // PATHNAME_H
